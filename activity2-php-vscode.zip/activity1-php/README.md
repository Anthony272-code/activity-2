# Activity 1 — PHP Sign In and Register

This project matches the Activity #1 instruction: "Create Sign In and Register Page of your website (any website)."

## Requirements
- XAMPP (Apache + MySQL)
- Visual Studio Code
- A browser

## Setup
1. Extract this ZIP.
2. Copy the `activity1-php` folder into `C:\xampp\htdocs\`.
3. Open XAMPP Control Panel and start **Apache** and **MySQL**.
4. Open `http://localhost/phpmyadmin`.
5. Select the **Import** tab, choose this project's `database.sql`, then click **Import** / **Go**.
   - Alternatively, open the SQL tab and paste the contents of `database.sql`.
6. Open `http://localhost/activity1-php/` in your browser.
7. Register an account, then sign in using that email and password.

## Pages
- `register.php` — create an account
- `login.php` — sign in
- `dashboard.php` — shown after successful sign in
- `logout.php` — sign out
- `config/database.php` — database connection settings
- `database.sql` — creates the database and users table

## Notes
- This uses PHP sessions, PDO prepared statements, and `password_hash()` / `password_verify()`.
- There is no preset account. Register your own account first.
- This is a classroom starter project. For public deployment, configure HTTPS, secure session cookies, CSRF protections appropriate to your deployment, rate limiting, and production database credentials.
