<?php
// Update these settings to match your XAMPP/MySQL configuration.
$host = "localhost";
$dbname = "activity1_auth";
$username = "root";
$password = ""; // XAMPP default is usually blank.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    exit("Database connection failed. Check config/database.php and make sure MySQL is running in XAMPP.");
}
