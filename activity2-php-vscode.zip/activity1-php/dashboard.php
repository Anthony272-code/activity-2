<?php
require_once __DIR__ . "/config/functions.php";
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | My Website</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<main class="page">
    <section class="auth-card dashboard-card">
        <div class="logo">M</div>
        <p class="eyebrow">YOUR ACCOUNT</p>
        <h1>Welcome, <?= e($_SESSION["user_name"] ?? "User") ?>!</h1>
        <p class="subtitle">You have successfully signed in to your website.</p>
        <div class="success-box">Your Activity #1 Sign In and Registration system is working.</div>
        <form method="POST" action="logout.php">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <button class="submit-button" type="submit">Sign Out</button>
        </form>
    </section>
</main>
</body>
</html>
