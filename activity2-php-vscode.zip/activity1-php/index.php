<?php
require_once __DIR__ . "/config/functions.php";
header("Location: " . (!empty($_SESSION["user_id"]) ? "dashboard.php" : "login.php"));
exit;
