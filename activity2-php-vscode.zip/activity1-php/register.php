<?php
require_once __DIR__ . "/config/functions.php";
require_once __DIR__ . "/config/database.php";

if (!empty($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}

$error = "";
$name = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter your full name and a valid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must contain at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);

        if ($check->fetch()) {
            $error = "This email is already registered. Please sign in.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $insert->execute([$name, $email, $hash]);

            session_regenerate_id(true);
            $_SESSION["user_id"] = (int)$pdo->lastInsertId();
            $_SESSION["user_name"] = $name;

            header("Location: dashboard.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | My Website</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<main class="page">
    <section class="auth-card">
        <div class="logo">M</div>
        <p class="eyebrow">GET STARTED</p>
        <h1>Create your account</h1>
        <p class="subtitle">Fill in the details below to register.</p>

        <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

        <form method="POST" action="register.php">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <div class="field">
                <label for="name">Full name</label>
                <input id="name" name="name" type="text" placeholder="Juan Dela Cruz" value="<?= e($name) ?>" required>
            </div>
            <div class="field">
                <label for="email">Email address</label>
                <input id="email" name="email" type="email" placeholder="you@example.com" value="<?= e($email) ?>" required>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" placeholder="At least 8 characters" minlength="8" required>
            </div>
            <div class="field">
                <label for="confirm_password">Confirm password</label>
                <input id="confirm_password" name="confirm_password" type="password" placeholder="Enter password again" minlength="8" required>
            </div>
            <button class="submit-button" type="submit">Create Account</button>
        </form>
        <p class="switch-text">Already have an account? <a href="login.php">Sign in</a></p>
    </section>
</main>
</body>
</html>
